from src.api_keys_db import is_valid_api_key


def extract_api_key(event):
    headers = event.get("headers", {}) or {}

    # Handle case variations
    return (
        headers.get("x-api-key")
        or headers.get("X-Api-Key")
        or headers.get("X-API-KEY")
    )


def require_api_key(event):
    key = extract_api_key(event)

    if not key or not is_valid_api_key(key):
        return False, {
            "statusCode": 403,
            "body": "Invalid or missing API key"
        }

    return True, None